import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';

// better-sqlite3 is preferred; Node 22+'s built-in node:sqlite is the automatic fallback.
let Database;
try { Database = (await import('better-sqlite3')).default; }
catch { Database = (await import('node:sqlite')).DatabaseSync; }

const dir = path.dirname(fileURLToPath(import.meta.url));
const file = process.env.DB_FILE || path.join(dir, 'data', 'jobcards.db');
if (file !== ':memory:') fs.mkdirSync(path.dirname(file), { recursive: true });

export const db = new Database(file);
db.exec(`
PRAGMA foreign_keys = ON;
CREATE TABLE IF NOT EXISTS customers (
  id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT, name TEXT NOT NULL UNIQUE COLLATE NOCASE,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS jobs (
  id INTEGER PRIMARY KEY AUTOINCREMENT, job_no TEXT NOT NULL UNIQUE, job_date TEXT NOT NULL,
  customer_id INTEGER REFERENCES customers(id), job_nature TEXT, plant TEXT NOT NULL,
  c_inch REAL, r_inch REAL, ups REAL, pcs_per_ctn REAL, sheet_qty REAL, carton_qty REAL,
  length_mm REAL, width_mm REAL, height_mm REAL, flap_size TEXT, notes TEXT,
  wastage_pct REAL DEFAULT 0, status TEXT DEFAULT 'Draft',
  created_at TEXT DEFAULT CURRENT_TIMESTAMP, updated_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS job_materials (
  id INTEGER PRIMARY KEY AUTOINCREMENT, job_id INTEGER NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
  line_no INTEGER NOT NULL, code TEXT, material TEXT, reel_size_inch REAL, gsm REAL, take_up REAL,
  open_balance_kg REAL, required_kg REAL, close_balance_kg REAL, status TEXT);
CREATE TABLE IF NOT EXISTS job_history (
  id INTEGER PRIMARY KEY AUTOINCREMENT, job_id INTEGER, job_no TEXT, action TEXT NOT NULL,
  snapshot TEXT NOT NULL, at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE INDEX IF NOT EXISTS idx_jobs_date ON jobs(job_date);
CREATE INDEX IF NOT EXISTS idx_mat_job ON job_materials(job_id);
`);
export function tx(fn) {
  db.exec('BEGIN');
  try { const r = fn(); db.exec('COMMIT'); return r; } catch (e) { db.exec('ROLLBACK'); throw e; }
}
