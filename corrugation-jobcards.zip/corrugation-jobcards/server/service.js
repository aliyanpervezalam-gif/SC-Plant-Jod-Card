import { db, tx } from './db.js';
import { jobCalc, validateJob, toNum } from '../shared/calc.js';

const n = (v) => toNum(v);
export class HttpError extends Error { constructor(status, message, details) { super(message); this.status = status; this.details = details; } }

function load(row) {
  if (!row) return null;
  const lines = db.prepare('SELECT * FROM job_materials WHERE job_id = ? ORDER BY line_no').all(row.id).map((m) => ({
    code: m.code ?? '', material: m.material ?? '', reel: m.reel_size_inch ?? '', gsm: m.gsm ?? '', takeUp: m.take_up ?? '', open: m.open_balance_kg ?? '' }));
  const job = { id: row.id, jobNo: row.job_no, date: row.job_date, customerName: row.customer_name, customerCode: row.customer_code ?? '',
    nature: row.job_nature ?? '', plant: row.plant, cInch: row.c_inch ?? '', rInch: row.r_inch ?? '', ups: row.ups ?? '', pcs: row.pcs_per_ctn ?? '',
    sheetQty: row.sheet_qty ?? '', lengthMm: row.length_mm ?? '', widthMm: row.width_mm ?? '', heightMm: row.height_mm ?? '', flap: row.flap_size ?? '',
    notes: row.notes ?? '', wastage: row.wastage_pct ?? 0, status: row.status, createdAt: row.created_at, updatedAt: row.updated_at, lines };
  job.calc = jobCalc(job);
  return job;
}
const BASE = 'SELECT j.*, c.name AS customer_name, c.code AS customer_code FROM jobs j LEFT JOIN customers c ON c.id = j.customer_id';
export const getJob = (id) => load(db.prepare(`${BASE} WHERE j.id = ?`).get(id));

export function listJobs({ q = '', from = '', to = '' } = {}) {
  const w = [], p = [];
  if (q) { w.push('(j.job_no LIKE ? OR c.name LIKE ?)'); p.push(`%${q}%`, `%${q}%`); }
  if (from) { w.push('j.job_date >= ?'); p.push(from); }
  if (to) { w.push('j.job_date <= ?'); p.push(to); }
  return db.prepare(`${BASE} ${w.length ? 'WHERE ' + w.join(' AND ') : ''} ORDER BY j.job_date DESC, j.id DESC`).all(...p).map(load);
}

export const jobNoExists = (jobNo, excludeId = 0) => !!db.prepare('SELECT 1 FROM jobs WHERE job_no = ? AND id != ?').get(String(jobNo).trim(), Number(excludeId) || 0);
export function nextJobNo() {
  const r = db.prepare("SELECT MAX(CAST(job_no AS INTEGER)) m FROM jobs WHERE job_no GLOB '[0-9]*'").get();
  return String((r?.m || 0) + 1);
}

function snapshot(id, action) {
  const j = getJob(id);
  if (j) db.prepare('INSERT INTO job_history (job_id, job_no, action, snapshot) VALUES (?,?,?,?)').run(j.id, j.jobNo, action, JSON.stringify(j));
}

function writeJob(id, d) {
  const errors = validateJob(d);
  if (errors.length) throw new HttpError(400, 'Please correct the job card.', errors);
  if (jobNoExists(d.jobNo, id)) throw new HttpError(409, `Job number ${d.jobNo} already exists.`);
  const name = d.customerName.trim();
  let cid = db.prepare('SELECT id FROM customers WHERE name = ?').get(name)?.id;
  if (cid) db.prepare('UPDATE customers SET code = ? WHERE id = ?').run(d.customerCode || null, cid);
  else cid = Number(db.prepare('INSERT INTO customers (code, name) VALUES (?,?)').run(d.customerCode || null, name).lastInsertRowid);
  const calc = jobCalc(d);
  const v = [d.jobNo.trim(), d.date, cid, d.nature || '', d.plant, n(d.cInch), n(d.rInch), n(d.ups), n(d.pcs), n(d.sheetQty), calc.cartonQty,
    n(d.lengthMm), n(d.widthMm), n(d.heightMm), d.flap || '', d.notes || '', n(d.wastage) || 0, d.status || 'Draft'];
  let jid = id;
  if (id) {
    db.prepare(`UPDATE jobs SET job_no=?, job_date=?, customer_id=?, job_nature=?, plant=?, c_inch=?, r_inch=?, ups=?, pcs_per_ctn=?, sheet_qty=?, carton_qty=?,
      length_mm=?, width_mm=?, height_mm=?, flap_size=?, notes=?, wastage_pct=?, status=?, updated_at=CURRENT_TIMESTAMP WHERE id=?`).run(...v, id);
    db.prepare('DELETE FROM job_materials WHERE job_id = ?').run(id);
  } else {
    jid = Number(db.prepare(`INSERT INTO jobs (job_no, job_date, customer_id, job_nature, plant, c_inch, r_inch, ups, pcs_per_ctn, sheet_qty, carton_qty,
      length_mm, width_mm, height_mm, flap_size, notes, wastage_pct, status) VALUES (${v.map(() => '?').join(',')})`).run(...v).lastInsertRowid);
  }
  const ins = db.prepare(`INSERT INTO job_materials (job_id, line_no, code, material, reel_size_inch, gsm, take_up, open_balance_kg, required_kg, close_balance_kg, status)
    VALUES (?,?,?,?,?,?,?,?,?,?,?)`);
  d.lines.forEach((l, i) => { const c = calc.lines[i];
    ins.run(jid, i + 1, l.code || '', l.material || '', n(l.reel), n(l.gsm), n(l.takeUp), n(l.open), c.required, c.close, c.status); });
  return jid;
}

export const createJob = (d) => tx(() => { const id = writeJob(0, d); snapshot(id, 'created'); return getJob(id); });
export function updateJob(id, d) {
  return tx(() => {
    if (!getJob(id)) throw new HttpError(404, 'Job card not found.');
    snapshot(id, 'before edit'); // the original data stays in history
    writeJob(id, d); snapshot(id, 'edited'); return getJob(id);
  });
}
export function deleteJob(id) {
  return tx(() => { if (!getJob(id)) throw new HttpError(404, 'Job card not found.'); snapshot(id, 'deleted'); db.prepare('DELETE FROM jobs WHERE id = ?').run(id); });
}
export function duplicateJob(id) {
  const j = getJob(id); if (!j) throw new HttpError(404, 'Job card not found.');
  return createJob({ ...j, jobNo: nextJobNo(), date: new Date().toISOString().slice(0, 10), status: 'Draft' });
}
export const history = (id) => db.prepare('SELECT id, action, at, snapshot FROM job_history WHERE job_id = ? ORDER BY id DESC').all(id).map((h) => ({ id: h.id, action: h.action, at: h.at, job: JSON.parse(h.snapshot) }));

export function dashboard() {
  const jobs = listJobs();
  const sumJ = (f) => jobs.reduce((a, j) => a + f(j), 0), r = (x) => Math.round(x * 10) / 10;
  const by = {};
  jobs.forEach((j) => { by[j.customerName] = (by[j.customerName] || 0) + j.calc.totalRequired; });
  return {
    totalJobs: jobs.length, totalSheets: sumJ((j) => toNum(j.sheetQty) || 0), totalCartons: sumJ((j) => j.calc.cartonQty),
    totalRequiredKg: r(sumJ((j) => j.calc.totalRequired)), totalStockKg: r(sumJ((j) => j.calc.totalOpen)),
    incompleteJobs: jobs.filter((j) => j.calc.gsmMissing || j.calc.noStock).length,
    alerts: jobs.filter((j) => j.calc.short).map((j) => ({ id: j.id, jobNo: j.jobNo, customerName: j.customerName, shortLines: j.calc.short })),
    recent: jobs.slice(0, 8).map(({ lines, ...j }) => j),
    byCustomer: Object.entries(by).sort((a, b) => b[1] - a[1]).slice(0, 6).map(([name, kg]) => ({ name, kg: r(kg) })),
  };
}

// First run only: the original Excel job card JS 2751 (its GSM is blank in the Excel, so weights stay blank until entered).
export function seedIfEmpty() {
  if (db.prepare('SELECT COUNT(*) c FROM jobs').get().c) return;
  const L = (code, material, takeUp, open) => ({ code, material, reel: 50, gsm: '', takeUp, open });
  createJob({ jobNo: '2751', date: '2026-10-22', customerName: 'Saca plus / MS Corporation Kenco Ctn', customerCode: 'SC', nature: '', plant: '3 Ply',
    cInch: 29.5, rInch: 50, ups: 3, pcs: 1, sheetQty: 670, lengthMm: 205, widthMm: 150, heightMm: 257, flap: '', notes: '', wastage: 0, status: 'Draft',
    lines: [L('2186', 'N Dubai', 1, 965), L('420', 'CMP', 1.35, 190), L('2188', 'N Dubai', 1, 915)] });
}
