import test from 'node:test';
import assert from 'node:assert/strict';
process.env.DB_FILE = ':memory:';
const { cartonQty, requiredWeight, jobCalc, validateJob, defaultTakeUp } = await import('../../shared/calc.js');
const S = await import('../service.js');

// The actual example from Job_Card_JS2751.xlsx
const job = (gsm = ['', '', '']) => ({ jobNo: '2751', date: '2026-10-22', customerName: 'Saca plus', plant: '3 Ply', cInch: 29.5, rInch: 50, ups: 3, pcs: 1, sheetQty: 670, wastage: 0,
  lines: [{ reel: 50, gsm: gsm[0], takeUp: 1, open: 965 }, { reel: 50, gsm: gsm[1], takeUp: 1.35, open: 190 }, { reel: 50, gsm: gsm[2], takeUp: 1, open: 915 }] });

test('Carton Qty = 670 x 3 x 1 = 2010', () => assert.equal(cartonQty(job()), 2010));
test('Required weight is blank while GSM is missing', () => { const c = jobCalc(job()); assert.equal(c.lines[0].required, null); assert.equal(c.lines[0].status, 'GSM MISSING'); });
test('Required weight matches the Excel formula (GSM 150, wastage 0)', () => {
  const expected = Math.round(29.5 * 0.0254 * 50 * 0.0254 * 150 * 670 * 1 * 1 / 1000 * 10) / 10;
  assert.equal(requiredWeight(job(), job(['150']).lines[0]), expected); assert.equal(expected, 95.6);
});
test('Close balance, status and totals', () => {
  const c = jobCalc(job(['150', '112', '150']));
  assert.deepEqual(c.lines.map((x) => x.required), [95.6, 96.4, 95.6]);
  assert.deepEqual(c.lines.map((x) => x.close), [869.4, 93.6, 819.4]); assert.equal(c.overall, 'OK');
  assert.equal(c.totalOpen, 2070); assert.equal(c.totalRequired, 287.6);
});
test('SHORT when reel is not enough; wastage % applied as (1 + w/100)', () => {
  const j = job(['150', '112', '150']); j.lines[0].open = 50; j.wastage = 10;
  const c = jobCalc(j); assert.equal(c.lines[0].status, 'SHORT'); assert.ok(c.lines[0].close < 0);
  assert.equal(c.lines[0].required, Math.round(29.5 * 0.0254 * 50 * 0.0254 * 150 * 670 * 1.1 / 1000 * 10) / 10);
});
test('Missing stock is never treated as zero', () => { const j = job(['150', '112', '150']); j.lines[0].open = ''; assert.equal(jobCalc(j).lines[0].status, 'NO STOCK DATA'); });
test('Take-up defaults and negative-number validation', () => {
  assert.equal(defaultTakeUp('CMP'), 1.35); assert.equal(defaultTakeUp('Fluting'), 1.35); assert.equal(defaultTakeUp('N Dubai'), 1);
  const j = job(); j.sheetQty = -5; assert.ok(validateJob(j).some((m) => m.includes('Sheet Qty')));
});
test('Database: seed, duplicate JS #, edit keeps history, duplicate, delete', () => {
  S.seedIfEmpty(); const [seed] = S.listJobs(); assert.equal(seed.jobNo, '2751'); assert.equal(seed.calc.cartonQty, 2010);
  assert.throws(() => S.createJob({ ...job(), jobNo: '2751' }), /already exists/);
  const d = S.createJob({ ...job(['150', '112', '150']), jobNo: S.nextJobNo() }); assert.equal(d.jobNo, '2752');
  const e = S.updateJob(d.id, { ...d, notes: 'edited' }); assert.equal(e.notes, 'edited'); assert.equal(S.history(d.id).length, 3);
  const c = S.duplicateJob(d.id); assert.equal(c.jobNo, '2753'); assert.equal(c.lines.length, 3);
  S.deleteJob(c.id); assert.equal(S.getJob(c.id), null); assert.equal(S.dashboard().totalJobs, 2);
});
