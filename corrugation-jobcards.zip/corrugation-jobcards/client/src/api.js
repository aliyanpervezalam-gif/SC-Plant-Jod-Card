async function call(url, opt) {
  const r = await fetch(url, { headers: { 'Content-Type': 'application/json' }, ...opt });
  const data = await r.json().catch(() => ({}));
  if (!r.ok) { const e = new Error(data.error || 'Request failed'); e.details = data.details; throw e; }
  return data;
}
export const api = {
  dashboard: () => call('/api/dashboard'),
  list: (p) => call('/api/jobs?' + new URLSearchParams(p)),
  get: (id) => call(`/api/jobs/${id}`),
  nextNo: () => call('/api/next-job-no'),
  noExists: (jobNo, exclude) => call('/api/job-no/check?' + new URLSearchParams({ jobNo, exclude: exclude || 0 })),
  create: (j) => call('/api/jobs', { method: 'POST', body: JSON.stringify(j) }),
  update: (id, j) => call(`/api/jobs/${id}`, { method: 'PUT', body: JSON.stringify(j) }),
  remove: (id) => call(`/api/jobs/${id}`, { method: 'DELETE' }),
  duplicate: (id) => call(`/api/jobs/${id}/duplicate`, { method: 'POST' }),
  history: (id) => call(`/api/jobs/${id}/history`),
};
